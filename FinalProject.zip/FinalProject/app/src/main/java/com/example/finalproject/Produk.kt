package com.example.finalproject

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Produk : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk)

        val rv_produk: RecyclerView = findViewById(R.id.rv_produk)

        val id:MutableList<String> = mutableListOf()
        val nama:MutableList<String> = mutableListOf()
        val harga:MutableList<String> = mutableListOf()
        val stok:MutableList<String> = mutableListOf()
        val foto:MutableList<Int> = mutableListOf()

        val dbproduk: SQLiteDatabase = openOrCreateDatabase("highgear", MODE_PRIVATE, null)
        val gali_produk = dbproduk.rawQuery("select * from produk",null)
        while (gali_produk.moveToNext())
        {
            id.add(gali_produk.getString(0))
            nama.add(gali_produk.getString(1))
            harga.add(gali_produk.getString(2))
            stok.add(gali_produk.getString(3))
            foto.add(R.drawable.noimage)
        }

        val mi:Produk_item = Produk_item(this,id,nama,harga,stok,foto)

        rv_produk.adapter = mi
        rv_produk.layoutManager = GridLayoutManager(this, 2)
        val btn_tambah: Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah: Intent = Intent(this, Produk_tambah::class.java)
            startActivity(pindah)
        }
    }
}