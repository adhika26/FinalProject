package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)

        val card_produk:CardView = findViewById(R.id.card_produk)
        val card_profile:CardView = findViewById(R.id.card_profile)
        val card_admin:CardView = findViewById(R.id.card_user)
        val card_logout:CardView = findViewById(R.id.card_logout)

        card_produk.setOnClickListener {
            val pindah:Intent = Intent(this, Produk::class.java)
            startActivity(pindah)
        }

        card_profile.setOnClickListener {
            val pindah:Intent = Intent(this, Profile::class.java)
            startActivity(pindah)
        }

        card_admin.setOnClickListener {
            val pindah:Intent = Intent(this, User::class.java)
            startActivity(pindah)
        }

        card_logout.setOnClickListener {
            val pindah:Intent = Intent(this, Login::class.java)
            startActivity(pindah)
        }
    }
}