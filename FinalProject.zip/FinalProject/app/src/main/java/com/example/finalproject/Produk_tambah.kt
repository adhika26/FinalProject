package com.example.finalproject

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText

class Produk_tambah : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_tambah)

        val edt_nama:EditText = findViewById(R.id.edt_nama)
        val edt_harga:EditText = findViewById(R.id.edt_harga)
        val edt_stok:EditText = findViewById(R.id.edt_stok)
        val btn_simpan:Button = findViewById(R.id.btn_simpan)

        btn_simpan.setOnClickListener {
            val isi_nama:String = edt_nama.text.toString()
            val isi_harga:String = edt_harga.text.toString()
            val isi_stok:String = edt_stok.text.toString()

            Log.d("nama produk", isi_nama)
            Log.d("harga produk", isi_harga)
            Log.d("stok produk", isi_stok)

            val dbkampus:SQLiteDatabase = openOrCreateDatabase("highgear", MODE_PRIVATE,null)
            val eksekutor = dbkampus.rawQuery("INSERT INTO produk(nama_produk,harga_produk,stok_produk) VALUES ('$isi_nama','$isi_harga','$isi_stok')",null)
            eksekutor.moveToNext()
            val pindah:Intent = Intent(this,Produk::class.java)
            startActivity(pindah)
        }
    }
}