package com.example.finalproject

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class Produk_ubah : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk_ubah)

        //dapatkan id mahasiswa terpilih yang dibawa saat klik tombol ubah
        val id_produk_terpilih:String = intent.getStringExtra("id_produk_terpilih").toString()

        //koneksi db
        val dbproduk:SQLiteDatabase = openOrCreateDatabase("highgear", MODE_PRIVATE, null)
        val ambil = dbproduk.rawQuery("SELECT * FROM produk WHERE id_produk = '$id_produk_terpilih'",null)
        ambil.moveToNext()

        val isi_nama:String = ambil.getString(1)
        val isi_harga:String = ambil.getString(2)
        val isi_stok:String = ambil.getString(3)

        val edt_nama:EditText = findViewById(R.id.edt_nama)
        val edt_harga:EditText = findViewById(R.id.edt_harga)
        val edt_stok:EditText = findViewById(R.id.edt_stok)
        val btn_simpan:Button = findViewById(R.id.btn_simpan)

        edt_nama.setText(isi_nama)
        edt_harga.setText(isi_harga)
        edt_stok.setText(isi_stok)

        //btn_simpan ditekan
        btn_simpan.setOnClickListener {
            val nama_baru:String = edt_nama.text.toString()
            val harga_baru:String = edt_harga.text.toString()
            val stok_baru:String = edt_stok.text.toString()

            val ngubah = dbproduk.rawQuery("UPDATE produk SET nama_produk='$nama_baru', harga_produk ='$harga_baru', stok_produk ='$stok_baru', WHERE id_produk='$id_produk_terpilih'",null)
            ngubah.moveToNext()

            val pindah:Intent = Intent(this, Produk::class.java)
            startActivity(pindah)
        }
    }
}