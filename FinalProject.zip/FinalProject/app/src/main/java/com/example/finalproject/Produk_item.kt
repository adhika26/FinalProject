package com.example.finalproject

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Produk_item (val ini:Context,val id:MutableList<String>,val nama:MutableList<String>, val harga:MutableList<String>, val stok:MutableList<String>, val foto:MutableList<Int>) : RecyclerView.Adapter<Produk_item.ViewHolder> () {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Produk_item.ViewHolder {
        val view:View = LayoutInflater.from(parent.context).inflate(R.layout.produk_item, parent, false)

        return ViewHolder(view)
    }

    class ViewHolder (iv:View) : RecyclerView.ViewHolder(iv){

        val txt_nama:TextView = iv.findViewById(R.id.txt_nama)
        val txt_harga:TextView = iv.findViewById(R.id.txt_harga)
        val txt_stok:TextView = iv.findViewById(R.id.txt_stok)
        val iv_foto:ImageView = iv.findViewById(R.id.iv_foto)
        val btn_hapus:Button = iv.findViewById(R.id.btn_hapus)
        val btn_ubah:Button = iv.findViewById(R.id.btn_ubah)
    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: Produk_item.ViewHolder, position: Int) {
        holder.txt_nama.text = nama.get(position)
        holder.txt_harga.text = harga.get(position)
        holder.txt_stok.text = stok.get(position)
        holder.iv_foto.setImageResource(foto.get(position))

        holder.btn_hapus.setOnClickListener {
            val id_produk_terpilih:String = id.get(position)

            val pindah:Intent = Intent(ini,Produk_hapus::class.java)
            pindah.putExtra("id_produk_terpilih", id_produk_terpilih)
            ini.startActivity(pindah)
        }
        //btn_ubah ditekan
        holder.btn_ubah.setOnClickListener {
            //dapatkan id mahasiswa
            val id_produk_terpilih:String = id.get(position)

            val pindah:Intent = Intent(ini,Produk_ubah::class.java)
            pindah.putExtra("id_produk_terpilih", id_produk_terpilih)
            ini.startActivity(pindah)
        }
    }

}